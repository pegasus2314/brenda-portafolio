# Portafolio — Brenda Iveth

Sitio de una sola página (HTML, CSS y JS autocontenidos). No requiere build ni dependencias de servidor.

## Subir a GitHub

```bash
git init
git add .
git commit -m "Portafolio Brenda Iveth"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/brenda-iveth-portafolio.git
git push -u origin main
```

## Desplegar en Vercel

1. Entra a vercel.com → **Add New Project** → importa el repositorio de GitHub.
2. Framework Preset: **Other** (es HTML plano, no necesita build command).
3. Build Command: deja vacío. Output Directory: deja vacío (o `.`).
4. Deploy.

## Editar con ChatGPT

Todo el código vive en `index.html` (HTML + `<style>` + `<script>` en un solo archivo). Puedes pegarle secciones de ese archivo a ChatGPT para pedir cambios puntuales (por ejemplo, solo el bloque `<style>`, o solo una función de `<script>`), y luego reemplazar esa parte en el archivo.

## Notas importantes

- El **modo edición** (botón "Editar" / panel de Brenda) usa una función `claude.use("artifact")` pensada para el entorno de artefactos de Claude. **Esa función no existe fuera de Claude.ai**, así que una vez desplegado en Vercel, el botón "Guardar y publicar" no funcionará — habrá que reemplazar esa lógica por algo que sí funcione en producción (por ejemplo, un formulario que mande los cambios por email, o conectarlo a un backend/CMS simple).
- El resto (3D con Three.js, sonido con Web Audio, tarjetas 3D, QR) es JavaScript estándar y funcionará igual en Vercel.
- Reemplaza las imágenes y textos de ejemplo (marcados como "pendiente") antes de publicar la versión final.
